import UIKit

var items: [Any] = [1.215, 16, "Aboba", true, true, 14.17, "AAbob", 1486]

for item in items {
    if let value = item as? Int {
        print("Int:\(value)")
    } else if let value = item as? Double {
        print("Double:\(value)")
    } else if let value = item as? String {
        print("String:\(value)")
    } else if let value = item as? Bool {
        print("Boolean:\(value)")
    }
 }


var numbers: [String:Any] = [
    "One": 16,
    "two": 6.23,
    "ddf33 df": "lowwww",
    "nccic": true,
    "eererer": false,
    "eer": 78.257,
    "last": "last"
]

for (key, value) in numbers {
    print("\(key):\(value)")
}

var total = 0.0

for (_, value) in numbers {
    if let item = value as? Int {
        total += Double(item)
    } else if let item = value as? Double {
        total += item
    } else if ((value as? String) != nil) {
        total += 1
    } else if let item = value as? Bool {
        if item { total += 2 }
        else { total += 3 }
    }
}
print(total)


for (_, value) in numbers {
    if let item = value as? Int {
        total += Double(item)
    } else if let item = value as? Double {
        total += item
    } else if let str = value as? String {
        for ch in str {
            total += Double(Character(extendedGraphemeClusterLiteral: ch).asciiValue!)
        }
    }
}

print(total)
