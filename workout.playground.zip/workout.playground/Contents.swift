import UIKit

class Workout {             // тренировка
    let time: Double        // время
    let distance: Double    // дистанция
    
    init(time: Double, distance: Double) {
        self.time = time
        self.distance = distance
    }
}

class Run: Workout {    // бег
    let cadence: Double // темп
    
    init(cadence: Double, time: Double, distance: Double) {
        self.cadence = cadence
        super.init(time: time, distance: distance)
    }
}

class Swim: Workout {   // плавание
    let stroke: String  // стиль
    
    init(stroke: String, time: Double, distance: Double) {
        self.stroke = stroke
        super.init(time: time, distance: distance)
    }
}

var workouts: [Workout] = [
    Run(cadence: 80, time: 1200, distance: 4000),
    Swim(stroke: "вольный стиль", time: 32.1, distance: 50),
    Swim(stroke: "баттерфляй", time: 36.8, distance: 50),
    Swim(stroke: "вольный стиль", time: 523.6, distance: 500),
    Run(cadence: 90, time: 358.9, distance: 1600)
]

func show_time(_ time:Double) ->String {
    if time < 60 {
        return "\(time) сек."
    } else {
        let min = Int(time/60)
        let sec = ceil(100*(time - Double(min * 60)))/100
        if sec == 0 {
        return "\(min) мин."
        } else {
            return "\(min) мин. \(sec) сек."
        }
    }
}

func show_distance(_ distance: Double) -> String {
    if distance > 800 { return "\(distance/1000) км."}
    else { return "\(Int(distance)) м."}
}

func describeRun(runningWorkout: Run) {
    print("--------------------\nТип тренировки: бег\nТемп: \(runningWorkout.cadence) шаг/мин\nВремя: \(show_time(runningWorkout.time))\nДистанция: \(show_distance(runningWorkout.distance))")
}

func describeSwim(swimmingWorkout: Swim) {
    print("--------------------\nТип тренировки: плаванье\nСтиль: \(swimmingWorkout.stroke)\nВремя: \(show_time(swimmingWorkout.time))\nДистанция: \(show_distance(swimmingWorkout.distance))")
}

for workout in workouts {
    if let running = workout as? Run {
        describeRun(runningWorkout: running)
    } else if let swimming = workout as? Swim {
        describeSwim(swimmingWorkout: swimming)
    }
}
